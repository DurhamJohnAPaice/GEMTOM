import numpy as np
from astroML.crossmatch import crossmatch_angular


def xmatch_arcsec(radec_arr1, radec_arr2, radius_arcsec=2):
    """Cross-match angular values between df1 and df2

    by default, this uses a KD Tree for speed.  Because the
    KD Tree only handles cartesian distances, the angles
    are projected onto a 3D sphere.
    The core function is provided by astroML.crossmatch

    Parameters
    ----------
    radec_arr1 : a numpy ndarray of shape (N1, 2)
        radec_arr1[:,0] is the RA and radec_arr1[:,1] is the DEC,
        both in degrees
    radec_arr2 : a numpy ndarray of shape (N2, 2)
        radec_arr2[:,0] is the RA and radec_arr2[:,1] is the DEC,
        both in degrees
    radius_arcsec : float (optional)
        maximum radius of search, measured in arcsec.
        If no point is within the given radius, then inf will be returned.

    Returns
    -------
    dist, ind: ndarrays
        The angular distance (arcsec) and index of the closest point in
        radec_arr2 to each point in radec_arr2.  Both arrays have length N1.
        Locations with no match are indicated by
        dist[i] = inf, ind[i] = N2
    """

    # imX1 = np.empty((len(df1), 2), dtype=np.float64)
    # imX1[:, 0] = np.asarray(df1.ra)
    # imX1[:, 1] = np.asarray(df1.dec)

    # imX2 = np.empty((len(df2), 2), dtype=np.float64)
    # imX2[:, 0] = np.asarray(df2.ra)
    # imX2[:, 1] = np.asarray(df2.dec)

    dist, ind = crossmatch_angular(radec_arr1, radec_arr2, radius_arcsec/3600)
    return 3600*dist, ind


def neighborsearch_arcsec(radec_arr1, radius_arcsec=5):
    """Find the nearest neighbors in arr1

    Every source in arr1 is crossmatched with the set to get
    neighboring sources within the specified radius.

    Parameters
    ----------
    radec_arr1 : a numpy ndarray of shape (N1, 2)
        radec_arr1[:,0] is the RA and radec_arr1[:,1] is the DEC,
        both in degrees
    radius_arcsec : float (optional)
        maximum radius of search, measured in arcsec.
        If no point is within the given radius, then inf will be returned.

    Returns
    -------
    nn: list of numpy.recarray
        A list of length N1 of rec arrays having the distances and ids of
        the neighboring sources. The length of the rec array corresponds
        to the number of found neighbors.
    """

    nn = []
    # dt = np.dtype({'names': ['dist_arcsec', 'ids'],
    #                'formats': [np.float64, np.int32]})
    for i, a in enumerate(radec_arr1):
        dist, ind = xmatch_arcsec(radec_arr1,
                                  a.reshape(1, 2),
                                  radius_arcsec=radius_arcsec)
        match = ~np.isinf(dist)
        # Take out the self match
        match[i] = False
        dist_match = dist[match]
        ids_match = (np.arange(len(radec_arr1))[match]).astype('int32')
        nn.append(np.rec.fromarrays((dist_match, ids_match),
                                    names=('dist_match', 'ids_match')))
    return nn
