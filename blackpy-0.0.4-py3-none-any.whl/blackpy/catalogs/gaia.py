import logging
import os
import sys
import numpy as np
from astroquery.gaia import Gaia

logging.getLogger('astroquery').setLevel(logging.WARNING)


class GaiaCatalog:

    DEFAULT_GAIA_ROWLIMIT = -1
    DEFAULT_GAIA_COLUMNS = ('source_id', 'ra', 'dec', 'parallax',
                            'pmra', 'pmdec', 'phot_g_mean_mag')

    def run_query(query, show_info=None):
        try:
            if show_info is True:
                print(query)

            job = Gaia.launch_job_async(query=query)
            if show_info is True:
                print(job)
            gaia_results = job.results
            if show_info is True:
                Gaia.remove_jobs([job.jobid])
            else:
                # Prevent the annoying print statement
                sys.stdout = open(os.devnull, 'w')
                Gaia.remove_jobs([job.jobid])
                sys.stdout = sys.__stdout__

            return tuple(gaia_results.colnames), gaia_results.as_array().data
        except Exception as e:
            print(e)
            return

    def get_source_byid(source_id, columns=None, show_info=None, gaia_dr=None):
        """Use min and max ra, dec to do a box search in the Gaia catalog

        """

        try:
            if columns is None:
                columns = '*'
            if show_info is None:
                show_info = False
            if gaia_dr is None:
                gaia_dr = 'gaiadr3'

            params = {'source_id': source_id,
                      'columns': ",".join(columns),
                      'gaia_dr': gaia_dr}

            queryframe = """\
            SELECT %(columns)s
              FROM %(gaia_dr)s.gaia_source
            WHERE source_id = %(source_id)s
            """
            query = queryframe % (params)
            if show_info is True:
                print(query)

            job = Gaia.launch_job_async(query=query)
            if show_info is True:
                print(job)
            gaia_results = job.results
            if show_info is True:
                Gaia.remove_jobs([job.jobid])
            else:
                # Prevent the annoying print statement
                sys.stdout = open(os.devnull, 'w')
                Gaia.remove_jobs([job.jobid])
                sys.stdout = sys.__stdout__

            return tuple(gaia_results.colnames), gaia_results.as_array().data

        except Exception as e:
            print(e)
            return

    def boxsearch(min_ra_deg, max_ra_deg, min_dec_deg, max_dec_deg,
                  columns=None,
                  row_limit=None,
                  show_info=None,
                  gaia_dr=None):
        """Use min and max ra, dec to do a box search in the Gaia catalog

        """

        try:
            if columns is None:
                columns = GaiaCatalog.DEFAULT_GAIA_COLUMNS

            if row_limit is None:
                row_limit = -1

            if show_info is None:
                show_info = False

            if gaia_dr is None:
                gaia_dr = 'gaiadr3'

            # Use the 64-bit precision
            params = {
                'min_ra_deg': np.float64(min_ra_deg),
                'max_ra_deg': np.float64(max_ra_deg),
                'min_dec_deg': np.float64(min_dec_deg),
                'max_dec_deg': np.float64(max_dec_deg),
                'columns': ",".join(columns),
                'row_limit': ("TOP {0}"
                              .format(row_limit)) if row_limit > 0 else "",
                'gaia_dr': gaia_dr}

            boxsearch_queryframe = """\
            SELECT %(row_limit)s
                   %(columns)s
              FROM %(gaia_dr)s.gaia_source
             WHERE ra BETWEEN %(min_ra_deg)s AND %(max_ra_deg)s
               AND dec BETWEEN %(min_dec_deg)s AND %(max_dec_deg)s
            """
            boxsearch_query = boxsearch_queryframe % (params)
            if show_info is True:
                print(boxsearch_query)

            job = Gaia.launch_job_async(query=boxsearch_query)
            if show_info is True:
                print(job)
            gaia_results = job.results
            if show_info is True:
                Gaia.remove_jobs([job.jobid])
            else:
                # Prevent the annoying print statement
                sys.stdout = open(os.devnull, 'w')
                Gaia.remove_jobs([job.jobid])
                sys.stdout = sys.__stdout__

            return tuple(gaia_results.colnames), gaia_results.as_array().data

        except Exception as e:
            print(e)
            return

    def conesearch(ra_deg, dec_deg, radius_arcsec=5,
                   columns=None,
                   row_limit=None,
                   show_info=None,
                   gaia_dr=None):
        """Use ra and dec to search in an area of radius in arcsec

        """

        try:
            # Use the 64-bit precision
            ra = np.float64(ra_deg)
            dec = np.float64(dec_deg)
            radius_deg = np.float64(radius_arcsec) / 3600

            if columns is None:
                columns = GaiaCatalog.DEFAULT_GAIA_COLUMNS

            if row_limit is None:
                row_limit = -1

            if show_info is None:
                show_info = False

            if gaia_dr is None:
                gaia_dr = 'gaiadr3'

            params = {
                'ra': ra,
                'dec': dec,
                'radius': radius_deg,
                'ra_column': 'ra',
                'dec_column': 'dec',
                'columns': ",".join(columns),
                'row_limit': ("TOP {0}"
                              .format(row_limit)) if row_limit > 0 else "",
                'gaia_dr': gaia_dr}

            conesearch_queryframe = """\
            SELECT
                  %(row_limit)s
                  %(columns)s,
                  DISTANCE(
                    POINT('ICRS', %(ra_column)s, %(dec_column)s),
                    POINT('ICRS', %(ra)s, %(dec)s)
                  ) AS dist
                FROM %(gaia_dr)s.gaia_source
                WHERE
                  1 = CONTAINS(
                    POINT('ICRS', %(ra_column)s, %(dec_column)s),
                    CIRCLE('ICRS', %(ra)s, %(dec)s, %(radius)s)
                  )
                ORDER BY
                  dist ASC
            """
            conesearch_query = conesearch_queryframe % (params)
            if show_info is True:
                print(conesearch_query)

            job = Gaia.launch_job_async(query=conesearch_query)
            if show_info is True:
                print(job)
            gaia_results = job.results
            if show_info is True:
                Gaia.remove_jobs([job.jobid])
            else:
                # Prevent the annoying print statement
                sys.stdout = open(os.devnull, 'w')
                Gaia.remove_jobs([job.jobid])
                sys.stdout = sys.__stdout__

            return tuple(gaia_results.colnames), gaia_results.as_array().data

        except Exception as e:
            print(e)
            return
