import numpy as np
from datetime import datetime
from datetime import timedelta


class TransientsCatalog:

    DEFAULT_ML_BOX_COLUMNS = ('id', 'ra_deg', 'dec_deg', 'datapoints')
    DEFAULT_ML_CONE_COLUMNS = ('id', 'datapoints', 'ra_deg', 'dec_deg')
    DEFAULT_ML_RUNCAT_COLUMNS = (
                'id', 'xtrsrc', 'datapoints', 'active', 'ra_rad', 'dec_rad',
                'ra_deg', 'dec_deg', 'dec_zone_deg', 'x', 'y', 'z', 'object',
                'iau_name')

    DEFAULT_ML_ASSOC_COLUMNS = (
                'a.xtrsrc', 'x.ra_psf_d', 'x.dec_psf_d',
                'x.flux_zogy', 'x.fluxerr_zogy',
                'x.mag_zogy', 'x.magerr_zogy',
                'i."mjd-obs"', 'i."date-obs"',
                'i.filter')

    TRANSIENT_HAS_ASTEROIDS = (
                'ta.xtrsrc', 'ti."date-obs"', 'ti.filter', 'ti.object',
                'ai.transfilename')

    TRANSIENTS_HAVE_ASTEROIDS = (
                'ta.runcat', 'ta.xtrsrc', 'ti."date-obs"', 'ti.filter',
                'ti.object', 'ai.transfilename')

    XTRSRC_IS_ASTEROID = (
                'tx.id', 'aa.id', 'aa.mag_v_sso', 'ti."date-obs"', 'ti.filter',
                'ti.object', 'ti.fitsfilename')

    XTRSRCS_ARE_ASTEROIDS = (
                'tx.id', 'aa.id', 'aa.mag_v_sso', 'ti."date-obs"', 'ti.filter',
                'ti.object', 'ti.fitsfilename')

    NEAREST_SKYTILES_COLUMNS = ('field_id', 'distance_deg')

    SKYTILE_OBSTIMES_COLUMNS = (
                'id', 'filter', '"date-obs"', '"mjd-obs"', '"tqc-flag"')

    def __init__(self, bg_instance):
        self.__bg = bg_instance

    def __get_runcat_xtrsrcs_bydate(self, nightdate_str=None, show_info=None):
        try:
            if nightdate_str is None:
                nightdate_str = datetime.utcnow().strftime("%Y-%m-%d")

            night_date = datetime.strptime(nightdate_str, "%Y-%m-%d")
            beginofnight = night_date.replace(hour=12)
            obsnightbegin_ts = beginofnight.strftime("%Y-%m-%d %H:%M:%S.%f")

            obsnightend_ts = (beginofnight + timedelta(days=1)).strftime(
                                "%Y-%m-%d %H:%M:%S.%f")

            if show_info is None:
                show_info = False

            columns = ('r.id',)
            params = {'obsnightbegin_ts': obsnightbegin_ts,
                      'obsnightend_ts': obsnightend_ts,
                      'columns': ",".join(columns)}

            queryframe = """\
            SELECT r.id
              FROM runcat r
                  ,extractedsource x
                  ,image i
             WHERE r.xtrsrc = x.id
               AND r.datapoints > 1
               AND x.image = i.id
               AND x.snr_zogy > 0
               AND i."date-obs" BETWEEN '%(obsnightbegin_ts)s'
                                    AND '%(obsnightend_ts)s'
            """
            query = queryframe % (params)
            if show_info is True:
                print(query)

            cursor = self.conn.cursor()
            cursor.execute(query)
            l_results = cursor.fetchall()
            cursor.close()

            return columns, l_results
        except Exception as e:
            print(e)
            return

    def get_first_transients(self, nightdate_str=None, show_info=None):
        try:
            print("Not implemented yet")
        except Exception as e:
            print(e)
            return

    def get_associations(self, transient_id, columns=None, show_info=None):
        try:
            if columns is None:
                columns = self.DEFAULT_ML_ASSOC_COLUMNS
            if show_info is None:
                show_info = False

            params = {'transient_id': transient_id,
                      'columns': ",".join(columns)}

            queryframe = """\
            SELECT %(columns)s
              FROM assoc a
                  ,extractedsource x
                  ,image i
             WHERE a.runcat = %(transient_id)s
               AND a.xtrsrc = x.id
               AND x.image = i.id
            ORDER BY i."date-obs"
            """
            query = queryframe % (params)
            if show_info is True:
                print(query)

            l_results = self.__bg.run_query(query)

            return columns, l_results

        except Exception as e:
            print(e)
            return

    def get_source_byid(self, transient_id, columns=None, show_info=None):
        try:
            if columns is None:
                columns = self.DEFAULT_ML_RUNCAT_COLUMNS
            if show_info is None:
                show_info = False

            params = {'transient_id': transient_id,
                      'columns': ",".join(columns)}

            queryframe = """\
            SELECT %(columns)s
              FROM runcat
            WHERE id = %(transient_id)s
            """
            query = queryframe % (params)
            if show_info is True:
                print(query)

            l_results = self.__bg.run_query(query)

            return columns, l_results

        except Exception as e:
            print(e)
            return

    def transient_has_asteroid_detection(
                                self,
                                transient_id,
                                columns=None,
                                show_info=None):
        """Use the transient id to check whether one or more of its datapoints
        (extracted sources) could be cross-matched with an asteroid.
        Returns a list of tuples of matched sources otherwise empty.

        Parameters
        ----------
        transient_id : int
            ID of the cataloged transient in runcat
        columns : tuple (optional)
            tuple of runcat columns names to be queried and returned
            If no value specified it defaults to TRANSIENT_HAS_ASTEROIDS

        Returns
        -------
        columns : tuple
            The names of the selected columns of the query
        results: array
            List of tuples of transient datapoints with asteroid match
        """
        try:
            if columns is None:
                columns = self.TRANSIENT_HAS_ASTEROIDS
            if show_info is None:
                show_info = False

            params = {'transient_id': transient_id,
                      'columns': ",".join(columns)}

            queryframe = """\
            SELECT %(columns)s
              FROM transients.assoc ta
                  ,transients.extractedsource tx
                  ,transients.image ti
                  ,asteroids.image ai
                  ,asteroids.asteroidsource aa
             WHERE ta.runcat = %(transient_id)s
               AND ta.xtrsrc = tx.id
               AND tx.image = ti.id
               AND ti.fitsfilename = ai.transfilename
               AND ai.id = aa.image
               AND tx.number = aa.number
            """
            query = queryframe % (params)
            if show_info is True:
                print(query)

            l_results = self.__bg.run_query(query)

            return columns, l_results

        except Exception as e:
            print(e)
            return

    def transients_have_asteroid_detection(
                                self,
                                transient_ids,
                                columns=None,
                                show_info=None):
        """Use a tuple of transient ids to check whether a transient had
        one or more of its datapoints (extracted sources) that could be
        cross-matched with an asteroid.
        Returns a list of tuples of matched sources otherwise empty.

        Parameters
        ----------
        transient_ids : tuple
            Tuple of ints of IDs of cataloged transients in runcat
        columns : tuple (optional)
            tuple of runcat columns names to be queried and returned
            If no value specified it defaults to TRANSIENTS_HAVE_ASTEROIDS

        Returns
        -------
        columns : tuple
            The names of the selected columns of the query
        results: array
            List of tuples of transient datapoints with asteroid match
        """
        try:
            if columns is None:
                columns = self.TRANSIENTS_HAVE_ASTEROIDS
            if show_info is None:
                show_info = False

            if len(transient_ids) == 0:
                return columns, []
            elif len(transient_ids) == 1:
                params = {'transient_ids': '(' + str(transient_ids[0]) + ')',
                          'columns': ",".join(columns)}
            else:
                params = {'transient_ids': tuple(transient_ids),
                          'columns': ",".join(columns)}

            queryframe = """\
            SELECT %(columns)s
              FROM transients.assoc ta
                  ,transients.extractedsource tx
                  ,transients.image ti
                  ,asteroids.image ai
                  ,asteroids.asteroidsource aa
             WHERE ta.runcat IN %(transient_ids)s
               AND ta.xtrsrc = tx.id
               AND tx.image = ti.id
               AND ti.fitsfilename = ai.transfilename
               AND ai.id = aa.image
               AND tx.number = aa.number
            """
            query = queryframe % (params)
            if show_info is True:
                print(query)

            l_results = self.__bg.run_query(query)

            return columns, l_results

        except Exception as e:
            print(e)
            return

    def xtrsrc_is_asteroid(self,
                           xtrsrc_id,
                           columns=None,
                           show_info=None):
        """Use the extracted source id to check whether it could be
        cross-matched with an asteroid.
        Returns a list of tuples of matched sources otherwise empty.

        Parameters
        ----------
        xtrsrc_id : int
            ID of the extracted source recorded in extractedsource
        columns : tuple (optional)
            tuple of runcat columns names to be queried and returned
            If no value specified it defaults to XTRSRC_IS_ASTEROID

        Returns
        -------
        columns : tuple
            The names of the selected columns of the query
        results: array
            List of tuples of extracted sources with asteroid match
        """
        try:
            if columns is None:
                columns = self.XTRSRC_IS_ASTEROID
            if show_info is None:
                show_info = False

            params = {'xtrsrc_id': xtrsrc_id,
                      'columns': ",".join(columns)}

            queryframe = """\
            SELECT %(columns)s
              from transients.extractedsource tx
                  ,transients.image ti
                  ,asteroids.image ai
                  ,asteroids.asteroidsource aa
             where tx.id = %(xtrsrc_id)s
               and tx.image = ti.id
               and ti.fitsfilename = ai.transfilename
               and ai.id = aa.image
               and tx.number = aa.number
            """
            query = queryframe % (params)
            if show_info is True:
                print(query)

            l_results = self.__bg.run_query(query)

            return columns, l_results

        except Exception as e:
            print(e)
            return

    def xtrsrcs_are_asteroid(self,
                             xtrsrc_ids,
                             columns=None,
                             show_info=None):
        """Use a tuple of extracted source IDs to check whether they could be
        cross-matched with an asteroid.
        Returns a list of tuples of matched sources otherwise empty.

        Parameters
        ----------
        xtrsrc_ids : int
            Tuple of ints of ID of the extracted source recorded in
            extractedsource
        columns : tuple (optional)
            tuple of runcat columns names to be queried and returned
            If no value specified it defaults to XTRSRCS_ARE_ASTEROIDS

        Returns
        -------
        columns : tuple
            The names of the selected columns of the query
        results: array
            List of tuples of extracted sources with asteroid match
        """
        try:
            if columns is None:
                columns = self.XTRSRCS_ARE_ASTEROIDS
            if show_info is None:
                show_info = False

            params = {'xtrsrc_ids': xtrsrc_ids,
                      'columns': ",".join(columns)}

            queryframe = """\
            SELECT %(columns)s
              from transients.extractedsource tx
                  ,transients.image ti
                  ,asteroids.image ai
                  ,asteroids.asteroidsource aa
             where tx.id IN %(xtrsrc_ids)s
               and tx.image = ti.id
               and ti.fitsfilename = ai.transfilename
               and ai.id = aa.image
               and tx.number = aa.number
            """
            query = queryframe % (params)
            if show_info is True:
                print(query)

            l_results = self.__bg.run_query(query)

            return columns, l_results

        except Exception as e:
            print(e)
            return

    def nearest_skytiles(self, ra_deg, dec_deg, radius_deg,
                         columns=None, show_info=None):
        """Use ra, dec and assoc_r to get the skytiles for which the
        centers fall within a radius from the given position

        Parameters
        ----------
        ra_deg : float
            RA coordinate in degrees
        dec_deg : float
            DEC coordinate in degrees
        radius_deg : float
            distance to field center in degrees
        columns : tuple (optional)
            tuple of runcat columns names to be queried and returned
            If no value specified it defaults to NEAREST_SKYTILES_COLUMNS

        Returns
        -------
        columns : tuple
            The names of the selected columns of the query
        results: array
            The field ids and distance of the nearest skytiles
        """
        try:
            # Use the 64-bit precision
            ra = np.float64(ra_deg)
            dec = np.float64(dec_deg)
            radius = np.float64(radius_deg)

            if columns is None:
                columns = self.NEAREST_SKYTILES_COLUMNS

            params = {'ra_deg': ra,
                      'dec_deg': dec,
                      'radius_deg': radius,
                      'columns': ",".join(columns)}

            qu = """\
            SELECT %(columns)s
              FROM nearest_fields(%(ra_deg)s,
                                  %(dec_deg)s,
                                  %(radius_deg)s)
            ORDER BY distance_deg
            """
            query = qu % (params)
            if show_info is True:
                print(query)

            l_results = self.__bg.run_query(query)

            return columns, l_results

        except Exception as e:
            print(e)
            return

    def skytile_observing_times(self, field_id, columns=None, show_info=None):
        """Get the observing times, filters and flags for the skytile
        specified by its 5-char field id

        Parameters
        ----------
        field : string
            field id string of length 5
        columns : tuple (optional)
            tuple of runcat columns names to be queried and returned
            If no value specified it defaults to SKYTILE_OBSTIMES_COLUMNS

        Returns
        -------
        columns : tuple
            The names of the selected columns of the query
        results: array
            The observation times of the given position
        """
        try:
            if len(field_id) != 5:
                message = 'Sky field ID must have exactly 5 digits'
                raise Exception(message)
            else:
                try:
                    message = 'Sky field ID must have exactly 5 digits'
                    int(field_id)
                except ValueError:
                    raise ValueError(message)

            if columns is None:
                columns = self.SKYTILE_OBSTIMES_COLUMNS

            params = {'object': field_id,
                      'columns': ",".join(columns)}

            qu = """\
            SELECT %(columns)s
              FROM image
             WHERE object = '%(object)s'
            ORDER BY "date-obs"
            """
            query = qu % (params)
            if show_info is True:
                print(query)

            l_results = self.__bg.run_query(query)

            return columns, l_results

        except Exception as e:
            print(e)
            return

    def boxsearch(self, min_ra_deg, max_ra_deg, min_dec_deg, max_dec_deg,
                  columns=None,
                  show_info=None):
        """Use min and max ra, dec to do a box search in transients catalog

        Parameters
        ----------
        min_ra_deg : float
            minimum RA coordinate in degrees
        max_ra_deg : float
            maximum RA coordinate in degrees
        min_dec_deg : float
            minimum DEC coordinate in degrees
        max_dec_deg : float
            maximum DEC coordinate in degrees
        columns : tuple (optional)
            tuple of runcat columns names to be queried and returned
            If no value specified it defaults to DEFAULT_ML_BOX_COLUMNS

        Returns
        -------
        columns : tuple
            The names of the selected columns of the query
        results: array
            The results of the cone search
        """
        try:
            # Use the 64-bit precision
            min_ra = np.float64(min_ra_deg)
            max_ra = np.float64(max_ra_deg)
            min_dec = np.float64(min_dec_deg)
            max_dec = np.float64(max_dec_deg)

            if columns is None:
                columns = self.DEFAULT_ML_BOX_COLUMNS

            params = {'min_ra_deg': min_ra, 'max_ra_deg': max_ra,
                      'min_dec_deg': min_dec, 'max_dec_deg': max_dec,
                      'columns': ",".join(columns)}

            boxsearch_queryframe = """\
            SELECT %(columns)s
              FROM runcat
             WHERE ra_deg BETWEEN %(min_ra_deg)s AND %(max_ra_deg)s
               AND dec_deg BETWEEN %(min_dec_deg)s AND %(max_dec_deg)s
            """
            query = boxsearch_queryframe % (params)
            if show_info is True:
                print(query)

            l_results = self.__bg.run_query(query)

            return columns, l_results

        except Exception as e:
            print(e)
            return

    def conesearch(self, ra_deg, dec_deg, radius_arcsec=5,
                   columns=None,
                   show_info=None):
        """Use ra, dec to do a cone search in transients catalog

        by default the cone radius is 5 arcsec and can be maximized
        to 4200 arcsec, about the size of a ML/BG sky-tile field.

        Parameters
        ----------
        ra_deg : float
            RA coordinate in degrees
        dec_deg : float
            DEC coordinate in degrees
        radius_arcsec : float (optional)
            cone radius of search in arcsec.
            If no value specified it defaults to 5 arcsec. A maximum
            of 4200 arcsec can be given.

        Returns
        -------
        columns, results: arrays
            The names of the selected columns of the query, and
            the results of the cone search
        """
        try:
            if columns is None:
                columns = self.DEFAULT_ML_CONE_COLUMNS

            # Use the 64-bit precision
            ra = np.float64(ra_deg)
            dec = np.float64(dec_deg)
            if radius_arcsec > 4200:
                print('Max radius is 4200 arcsec')
                return
            radius = np.float64(radius_arcsec)
            radius_deg = np.float64(radius_arcsec) / 3600.

            # Calculate the Cartesian co-ordinates
            x_c = np.cos(np.radians(dec)) * np.cos(np.radians(ra))
            y_c = np.cos(np.radians(dec)) * np.sin(np.radians(ra))
            z_c = np.sin(np.radians(dec))

            # Set some parameters that we will plug in into the query
            params = {}
            params['dot_product'] = (
                            "({0} - x) * ({0} - x) + \n"
                            "({1} - y) * ({1} - y) + \n"
                            "({2} - z) * ({2} - z)"
                            .format(x_c, y_c, z_c))

            # Set the declination zones, this speeds up the search
            dec_min = dec - radius_deg
            dec_max = dec + radius_deg
            minzone = int(np.floor(dec_min))
            maxzone = int(np.floor(dec_max))
            params['dec_zone_between'] = (
                            "AND dec_zone_deg BETWEEN {0} AND {1}"
                            .format(minzone, maxzone))
            params['dec_between'] = (
                            "AND dec_deg BETWEEN {0} AND {1}"
                            .format(dec_min, dec_max))

            # This is used to compare the dot product with
            isint2 = 4 * np.sin(np.radians(radius / 7200.))**2
            params['isint2'] = "AND t.dist < {0}".format(isint2)

            params['columns'] = ",".join(columns)

            conesearch_queryframe = """\
            SELECT %(columns)s
                  ,3600 * sys.DEGREES(2 * ASIN(SQRT(t.dist) / 2))
                   AS distance_arcsec
              FROM (SELECT %(columns)s
                          ,%(dot_product)s AS dist
                      FROM runcat r
                     WHERE TRUE
                       %(dec_zone_between)s
                       %(dec_between)s
                    ) t
             WHERE TRUE
               %(isint2)s
            ORDER BY distance_arcsec
            """
            query = conesearch_queryframe % (params)
            if show_info is True:
                print(query)

            l_results = self.__bg.run_query(query)

            return columns + ('distance_arcsec',), l_results
        except Exception as e:
            print(e)
            return

    def xmatch(self, df_sources_left, df_sources_right, assoc_r_arcsec):
        print("len(left) = {0}\nlen(right) = {1}"
              .format(len(df_sources_left), len(df_sources_right)))
        print("Not implemented yet")
        pass
