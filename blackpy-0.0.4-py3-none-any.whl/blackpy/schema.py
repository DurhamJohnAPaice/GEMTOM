import pandas as pd


class Schema:

    def __init__(self, bg_instance):
        self.__bg = bg_instance

    def get_schemas(self):
        """Show the schema names in the database

        This function shows the names of the schemas in the database
        to which the user has access to.

        """
        query = """\
        SELECT s.name AS schemaname
          FROM sys.schemas s
         WHERE s.system = FALSE
        ORDER BY s.name
        """

        try:
            l_results = self.__bg.run_query(query)
            l_columns = ['schemaname']
            return pd.DataFrame(l_results, columns=l_columns)
        except Exception as e:
            print(e)
            return

    def get_normaltables(self, schemaname='transients'):
        """Show the normal tables in the schema

        This function shows the names of the normal tables in the schema.
        Normal tables do not have any partition table defined under it,
        nor is it part of a merge table definition.

        Parameters
        ----------
        schemaname: str
            The name of the database schema, defaults to transients

        """
        qu = """\
        SELECT t.name AS normaltablename
          FROM sys.tables t
              ,(SELECT u.id AS table_id
                  FROM (SELECT t.id
                              ,t.name
                          FROM sys.tables t
                              ,sys.schemas s
                         WHERE t.schema_id = s.id
                           AND s.name = '%(schemaname)s'
                       ) u
                       LEFT OUTER JOIN sys.objects o
                       on u.id = o.sub
                 WHERE o.sub IS NULL
                EXCEPT
                SELECT
                      o.nr AS partitiontableid
                  FROM (SELECT t.id
                              ,t.name
                          FROM sys.tables t
                              ,sys.schemas s
                         WHERE t.schema_id = s.id
                           AND s.name = '%(schemaname)s'
                       ) u
                       LEFT OUTER JOIN sys.objects o
                       ON u.id = o.sub
                 WHERE o.sub IS NOT NULL
               ) v
         WHERE t.id = v.table_id
        ORDER BY t.name
        """
        params = {'schemaname': schemaname}
        query = qu % (params)

        try:
            l_results = self.__bg.run_query(query)
            l_columns = ['normal_tablename']
            return pd.DataFrame(l_results, columns=l_columns)
        except Exception as e:
            print(e)
            return

    def get_mergetables(self, schemaname='transients'):
        """Show the merge tables in the schema

        This function shows the names of the merge tables in the schema.
        A merge table can be considered as a parent table, under which
        several partition tables are defined. The partitioning scheme is
        defined according to declination zones.

        Parameters
        ----------
        schemaname: str
            The name of the database schema, defaults to transients

        """
        qu = """\
            SELECT t.name
              FROM sys.tables t
                  ,sys.schemas s
             WHERE t.schema_id = s.id
               AND s.name = '%(schemaname)s'
               AND t.type = 3
            ORDER BY t.name
        """
        params = {'schemaname': schemaname}
        query = qu % (params)

        try:
            l_results = self.__bg.run_query(query)
            l_columns = ['merge_tablename']
            return pd.DataFrame(l_results, columns=l_columns)
        except Exception as e:
            print(e)
            return

    def get_partitiontables(self,
                            schemaname='transients',
                            merge_tablename=None):
        """Show the partition tables in the schema

        This function shows the names of the partition tables in the schema.
        If a merge table name is provided it will only show the names of
        the partition tables that belong to the merge table.
        A partition table can be considered as a child table, above which
        a single parent table, i.e., a merge table, is defined.
        Partition tables are defined per declination zone (using 1-degree
        zones).

        Parameters
        ----------
        schemaname: str
            The name of the database schema, defaults to transients
        merge_tablename: str
            The name of the merge table in database schema, defaults
            to None in which case all partition tables will be shown.

        """
        if merge_tablename is None:
            qu = """\
            SELECT t.id AS merge_table_id
                  ,t.name AS merge_tablename
                  ,o.nr AS partition_table_id
                  ,o.name AS partition_tablename
              FROM sys.tables t
                  ,sys.schemas s
                  ,sys.objects o
             WHERE t.schema_id = s.id
               AND t.id = o.nr
               AND s.name = '%(schemaname)s'
            ORDER BY t.name
                    ,o.name
            """
            params = {'schemaname': schemaname}
        else:
            qu = """\
            SELECT t.id AS merge_table_id
                  ,t.name AS merge_tablename
                  ,o.nr AS partition_table_id
                  ,o.name AS partition_tablename
            FROM sys.tables t
                ,sys.schemas s
                ,sys.objects o
             WHERE t.schema_id = s.id
               AND t.id = o.nr
               AND s.name = '%(schemaname)s'
               AND t.name = '%(merge_tablename)s'
            ORDER BY t.name
                    ,o.name
            """
            params = {'schemaname': schemaname,
                      'merge_tablename': merge_tablename}
        query = qu % (params)

        try:
            l_results = self.__bg.run_query(query)
            l_columns = ['merge_table_id', 'merge_tablename',
                         'partition_table_id', 'partition_tablename']
            return pd.DataFrame(l_results,
                                columns=l_columns)[['merge_tablename',
                                                    'partition_tablename']]
        except Exception as e:
            print(e)
            return

    def get_columns(self, tablename, schemaname='transients'):
        """Show the columns of the table

        This function shows the columns of a table, together with the data
        types, bit sizes, default values, nulls.

        Parameters
        ----------
        tablename: str
            The name of a merge, partition or normal table

        schemaname: str
            The name of the database schema, defaults to transients

        """
        params = {'schemaname': schemaname,
                  'tablename': tablename}
        columns_query_frame = """\
        select c.name
              ,c.type AS datatype
              ,c.type_digits
              ,c."default"
              /*,c.number AS column_number*/
              ,k.remark
          from sys.tables t
              ,sys.schemas s
              ,sys.columns c
               left outer join sys.comments k
               on c.id = k.id
         where c.table_id = t.id
           and t.schema_id = s.id
           and s.name = '%(schemaname)s'
           and t.name = '%(tablename)s'
        ORDER BY c.number
        """
        query = columns_query_frame % (params)

        try:
            l_results = self.__bg.run_query(query)
            l_columns = ['name', 'datatype', 'type_digits',
                         'default', 'comment']
            df_results = pd.DataFrame(l_results, columns=l_columns)
            return df_results
        except Exception as e:
            print(e)
            return

    def get_records_table(self,
                          tablename,
                          schemaname='transients'):
        """Show the number of records of a table

        This function shows the number of records for the specified table.

        Parameters
        ----------
        schemaname: str
            The name of the database schema, defaults to transients
        tablename: str
            The name of the table in the database schema, a name
            must be provided.

        """
        qu = """\
        SELECT COUNT(*)
        FROM "%(schemaname)s"."%(tablename)s"
        """
        params = {'schemaname': schemaname,
                  'tablename': tablename}
        query = qu % (params)

        try:
            l_results = self.__bg.run_query(query)
            return l_results[0][0]
        except Exception as e:
            print(e)
            return
