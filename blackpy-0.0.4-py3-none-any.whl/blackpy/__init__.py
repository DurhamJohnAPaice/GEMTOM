from pymonetdb.sql.connections import Connection as connect
from pbr.version import VersionInfo

__version__ = VersionInfo('blackpy').version_string()


class BlackGEM:

    def __init__(self, creds_user_file=None, creds_db_file=None):
        try:
            with open(creds_db_file) as f:
                self.dbhost = f.readline().strip()
                self.dbport = int(f.readline().strip())
                self.dbname = f.readline().strip()
            with open(creds_user_file) as f:
                self.dbuser = f.readline().strip()
                self.dbpw = f.readline().strip()
            # self.__conn = self.__connectMonetDB()
            self.__conn = None
        except Exception as e:
            self.dbhost = None
            self.dbport = None
            self.dbname = None
            self.dbuser = None
            self.dbpw = None
            self.__conn = None
            print(e)

    def __del__(self):
        if self.__conn:
            self.__conn.close()

    def __connectMonetDB(self):
        try:
            monetdb_conn = connect(database=self.dbname,
                                   hostname=self.dbhost,
                                   port=self.dbport,
                                   username=self.dbuser,
                                   password=self.dbpw)
        except Exception as e:
            monetdb_conn = None
            print(e)
        return monetdb_conn

    @property
    def conn(self):
        return self.__conn

    def run_query(self, query):
        try:
            if self.__conn:
                cursor = self.__conn.cursor()
            else:
                self.__conn = self.__connectMonetDB()
                cursor = self.__conn.cursor()
            cursor.execute(query)
            results = cursor.fetchall()
            cursor.close()
            if self.__conn:
                self.__conn.close()
                self.__conn = None
            return results
        except Exception as e:
            if self.__conn:
                self.__conn.close()
                self.__conn = None
            print(e)
            print("An exception occurred, you have to reconnect")
            return
